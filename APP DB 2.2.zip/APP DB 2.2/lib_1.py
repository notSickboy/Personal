import pandas as pd
import re
import os
import tkinter as tk
from tkinter import messagebox, filedialog
import chardet

def traducir_espaniol_a_ingles(texto):
    reemplazos = {
        r'Evento\s+#': 'Event #',
        r'Gráfica:': 'Graph:',
        r'\s+a\. m\.': ' a. m.',
        r'\s+p\. m\.': ' p. m.',
    }
    for esp, eng in reemplazos.items():
        texto = re.sub(esp, eng, texto)
    texto = re.sub(r'(\d{2})/(\d{2})/(\d{4})', lambda m: f"{m.group(1)}/{m.group(2)}/{m.group(3)}", texto)
    return texto

def extraer_eventos(texto):
    patron = r'Event\s+#(\d+)\s*/\s*\d{2}/\d{2}/\d{4}\s+(\d{2}:\d{2}:\d{2})\s+[ap]\. m\.\s+Graph:\s+(\d+)'
    coincidencias = re.findall(patron, texto)
    df = pd.DataFrame(coincidencias, columns=['Evento', 'Hora', 'Graph'])
    df['Evento'] = df['Evento'].astype(int)
    df['Graph'] = df['Graph'].astype(str)
    return df

def detectar_codificacion(ruta):
    with open(ruta, 'rb') as f:
        resultado = chardet.detect(f.read(10000))
    return resultado['encoding']

def main():
    root = tk.Tk()
    root.withdraw()

    archivo_txt = filedialog.askopenfilename(
        title='Selecciona el archivo .txt con los eventos y horas...',
        filetypes=[("Text files", "*.txt")]
    )
    if not archivo_txt:
        messagebox.showwarning("Advertencia", "No se seleccionó archivo de texto.")
        return

    with open(archivo_txt, 'r', encoding='utf-8') as f:
        contenido_txt = f.read()

    if 'Gráfica:' in contenido_txt or 'Evento #' in contenido_txt:
        contenido_txt = traducir_espaniol_a_ingles(contenido_txt)

    df_eventos = extraer_eventos(contenido_txt)

    archivos_csv = filedialog.askopenfilenames(
        title='Selecciona uno o más archivos .CSV(SPG) para modificar directamente...',
        filetypes=[("CSV Files", "*.csv")]
    )

    if not archivos_csv:
        print("❌ No se seleccionaron archivos CSV.")
        return

    for archivo_csv in archivos_csv:
        print(f"\n📄 Editando archivo: {os.path.basename(archivo_csv)}")

        # Detectar codificación
        encoding = detectar_codificacion(archivo_csv)
        df_csv = pd.read_csv(archivo_csv, encoding=encoding)

        if not {'Event #', 'Graph Serial', 'Time'}.issubset(df_csv.columns):
            print(f"❌ Columnas requeridas no encontradas en {archivo_csv}")
            continue

        df_csv['Event #'] = pd.to_numeric(df_csv['Event #'], errors='coerce').astype('Int64')
        df_csv['Graph Serial'] = pd.to_numeric(df_csv['Graph Serial'], errors='coerce').dropna().astype(int).astype(str)

        reemplazos = 0
        for i, row in df_csv.iterrows():
            evento = row['Event #']
            graph = row['Graph Serial']
            if pd.notna(evento):
                match = df_eventos[(df_eventos['Evento'] == evento) & (df_eventos['Graph'] == graph)]
                if not match.empty:
                    nueva_hora = match.iloc[0]['Hora']
                    df_csv.at[i, 'Time'] = nueva_hora
                    reemplazos += 1

        print(f"✅ Reemplazos realizados: {reemplazos}")

        # Sobrescribir archivo original
        df_csv.to_csv(archivo_csv, index=False, encoding=encoding)
        print(f"💾 Guardado: {archivo_csv}")

if __name__ == "__main__":
    main()
