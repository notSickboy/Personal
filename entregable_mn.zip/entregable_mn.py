import os
import re
import shutil
from pathlib import Path
import hashlib
import pandas as pd

# ===== CONFIG =====
BASE_DIR = Path(r"C:\Users\Usuario_sino\Documents\Python_Monitoreo\entregable\ENTREGABLE")
CSV_PATH = Path(r"C:\Users\Usuario_sino\Documents\Python_Monitoreo\entregable\db_filtrado.csv")
NOMIS_BASE = Path(r"C:\Users\Usuario_sino\Documents\NOMIS")
FOTOS_BASE = Path(r"C:\Users\Usuario_sino\Documents\BASE_DE_DATOS\FOTOS_ALACTE")

ZIPPER_FOLDERS = ["ZIPPER M", "ZIPPER N"]

COL_FECHA = "FECHA"
COL_RUTA_PDF = "DIRECCION"
COL_ZIPPER = "ZIPPER"
COL_SERIE = "SERIE # NOMI"
COL_EVT = "# EVENTO"

MESES_ES = {
    1: "ENERO", 2: "FEBRERO", 3: "MARZO", 4: "ABRIL",
    5: "MAYO", 6: "JUNIO", 7: "JULIO", 8: "AGOSTO",
    9: "SEPTIEMBRE", 10: "OCTUBRE", 11: "NOVIEMBRE", 12: "DICIEMBRE"
}

SUBS = [
    Path(r"1.-DATOS DE CAMPO"),
    Path(r"1.-DATOS DE CAMPO\GRAFICAS DE MONITOREO"),
    Path(r"1.-DATOS DE CAMPO\EVENTOS"),
    Path(r"2.-FOTOS"),
]

# -------- Utilidades --------
def leer_csv_robusto(path_csv: Path, **kwargs) -> pd.DataFrame:
    candidatas = ["utf-8", "utf-8-sig", "cp1252", "latin-1", "iso-8859-1"]
    last_err = None
    for enc in candidatas:
        try:
            print(f"[INFO] Intentando leer CSV con encoding={enc} ...")
            df = pd.read_csv(path_csv, encoding=enc, **kwargs)
            print(f"[OK] Leído con encoding={enc}")
            return df
        except Exception as e:
            last_err = e
            print(f"[FALLO] encoding={enc}: {e}")
    print("[AVISO] Todos los encodings comunes fallaron. Intento final con errors='ignore'.")
    df = pd.read_csv(path_csv, encoding="latin-1", errors="ignore", **kwargs)
    print("[OK] Leído con latin-1 + errors='ignore'")
    return df

def month_folder_for_nomis(dt):
    mes = MESES_ES[dt.month]
    yy = dt.strftime("%y")
    return f"{mes}_{yy}"

def ddmmyy(dt):
    return dt.strftime("%d%m%y")

def dd_mm_yyyy(dt):
    return dt.strftime("%d-%m-%Y")

def find_range_folder_for_event(range_dirs, evt_num):
    rx = re.compile(r"Evts\s+(\d+)\s*-\s*(\d+)$", re.IGNORECASE)
    for rd in range_dirs:
        m = rx.match(rd.name.strip())
        if not m:
            continue
        low, high = int(m.group(1)), int(m.group(2))
        if low <= evt_num <= high:
            return rd
    return None

def candidate_event_names(evt_num):
    return [
        f"Evt{evt_num}.ns8",
        f"Evt{evt_num:02d}.ns8",
        f"Evt{evt_num:03d}.ns8",
        f"Evt{evt_num:04d}.ns8",
    ]

def build_pdf_dst_name(src_pdf: Path, serie: str) -> str:
    """
    '190725_4_1.pdf' + serie '20205' -> '190725_20205_1.pdf'
    Si no cumple patrón, usa 'stem_20205.pdf'.
    """
    serie_clean = re.sub(r"\D+", "", str(serie).strip())
    stem = src_pdf.stem
    parts = stem.split("_")
    if len(parts) >= 3:
        new_name = f"{parts[0]}_{serie_clean}_{parts[-1]}.pdf"
    else:
        new_name = f"{stem}_{serie_clean}.pdf"
    return new_name

def parse_pdf_tokens_from_direccion(path_str: str):
    try:
        stem = Path(path_str).stem
        parts = stem.split("_")
        if len(parts) >= 3:
            ddmmaa, id_str, ubic = parts[0], parts[1], parts[2]
            if re.fullmatch(r"\d{6}", ddmmaa):
                return ddmmaa, id_str, ubic
    except Exception:
        pass
    return None, None, None

def to_int_safe(x):
    try:
        return int(str(x).strip())
    except:
        return None

# ====== NUEVO: deduplicación por hash en una carpeta ======
RX_NOMBRE_PDF = re.compile(r"^(?P<ddmmaa>\d{6})_(?P<id>\d+?)_(?P<idx>\d+)\.pdf$", re.IGNORECASE)

def sha256(path: Path, bufsize: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(bufsize)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def id_len_from_name(name: str) -> int:
    m = RX_NOMBRE_PDF.match(name)
    return len(m.group("id")) if m else 0

def prefer_keep(a: Path, b: Path) -> Path:
    """Elige cuál conservar entre dos nombres de mismo hash.
       Regla: mayor longitud del ID; empate -> nombre más largo; empate -> el más reciente (mtime)."""
    la, lb = id_len_from_name(a.name), id_len_from_name(b.name)
    if la != lb:
        return a if la > lb else b
    if len(a.name) != len(b.name):
        return a if len(a.name) > len(b.name) else b
    return a if a.stat().st_mtime >= b.stat().st_mtime else b

def dedup_pdfs_por_hash(carpeta: Path) -> dict:
    """
    Deduplica por hash dentro de 'carpeta'. Mantiene 1 por hash.
    Devuelve {'borrados': n, 'grupos': m}
    """
    if not carpeta.exists():
        return {"borrados": 0, "grupos": 0}
    archivos = [p for p in carpeta.iterdir() if p.is_file() and p.suffix.lower() == ".pdf"]
    if not archivos:
        return {"borrados": 0, "grupos": 0}

    mapa = {}
    for p in archivos:
        try:
            h = sha256(p)
        except Exception as e:
            print(f"[AVISO] No pude hashear {p}: {e}")
            continue
        mapa.setdefault(h, []).append(p)

    borrados = 0
    for h, arr in mapa.items():
        if len(arr) < 2:
            continue
        keep = arr[0]
        for p in arr[1:]:
            keep = prefer_keep(keep, p)
        # borrar los demás
        for p in arr:
            if p == keep:
                continue
            try:
                p.unlink()
                borrados += 1
                print(f"[ELIMINADO][DUP] {p.name} (hash={h[:8]}) -> se conserva {keep.name}")
            except Exception as e:
                print(f"[ERROR] No pude eliminar {p}: {e}")
    grupos = sum(1 for arr in mapa.values() if len(arr) > 1)
    if grupos:
        print(f"[DEDUP] {grupos} grupos, {borrados} archivos retirados en {carpeta}")
    return {"borrados": borrados, "grupos": grupos}

def borrar_carpetas_vacias(raiz: Path):
    """
    Borra directorios vacíos (post-movidas). Recorre de más profundo a raíz.
    """
    if not raiz.exists():
        return 0
    count = 0
    # recorrer en post-orden
    for dirpath, dirnames, filenames in os.walk(raiz, topdown=False):
        p = Path(dirpath)
        try:
            # si está vacío (sin archivos ni subdirs)
            if not any(p.iterdir()):
                p.rmdir()
                count += 1
                print(f"[LIMPIO] Carpeta vacía removida: {p}")
        except Exception:
            pass
    return count

# ===== NUEVO: eliminar carpetas cortas (1-2 dígitos) dentro de 2.-FOTOS =====
def eliminar_carpetas_fotos_ids_cortos(roots):
    """
    Dentro de cada carpeta '2.-FOTOS' provista en 'roots',
    elimina (recursivamente) subcarpetas cuyo nombre sea 1 o 2 dígitos (^\d{1,2}$).
    Solo primer nivel por claridad.
    """
    rx_corto = re.compile(r"^\d{1,2}$")
    total = 0
    for root in sorted(roots):
        if not root or not Path(root).exists():
            continue
        for child in root.iterdir():
            if child.is_dir() and rx_corto.fullmatch(child.name):
                try:
                    shutil.rmtree(child)
                    total += 1
                    print(f"[ELIMINADO][FOTOS-ID-CORTO] {child}")
                except Exception as e:
                    print(f"[ERROR] Al eliminar {child}: {e}")
    return total

# -------- Main --------
def main():
    if not BASE_DIR.exists():
        print(f"[OMITIDO] La ruta base no existe: {BASE_DIR}")
        return
    if not CSV_PATH.exists():
        print(f"[ERROR] No se encontró el CSV: {CSV_PATH}")
        return
    if not NOMIS_BASE.exists():
        print(f"[ERROR] No existe la ruta NOMIS: {NOMIS_BASE}")
        return
    if not FOTOS_BASE.exists():
        print(f"[AVISO] No existe la ruta de FOTOS: {FOTOS_BASE} (se omitirá fase FOTOS si no está)")

    # Cargar CSV
    try:
        df = leer_csv_robusto(CSV_PATH, dtype=str)
    except Exception as e:
        print(f"[ERROR] No se pudo leer el CSV: {e}")
        return

    # Validar columnas
    req_cols = [COL_FECHA, COL_RUTA_PDF, COL_ZIPPER, COL_SERIE, COL_EVT]
    faltantes = [c for c in req_cols if c not in df.columns]
    if faltantes:
        print(f"[ERROR] Faltan columnas en el CSV: {faltantes}")
        return

    # Parseo de fecha y limpieza
    df["_FECHA_DT"] = pd.to_datetime(df[COL_FECHA], errors="coerce", dayfirst=True)
    bad = df[df["_FECHA_DT"].isna()]
    if not bad.empty:
        print(f"[AVISO] {len(bad)} filas con FECHA inválida serán omitidas.")
    df = df[df["_FECHA_DT"].notna()].copy()

    # Normalizar ZIPPER a M/N
    df[COL_ZIPPER] = df[COL_ZIPPER].astype(str).str.strip().str.upper()
    df = df[df[COL_ZIPPER].isin(["M", "N"])].copy()

    # Limpiar DIRECCION para PDFs
    df["_RUTA_PDF"] = df[COL_RUTA_PDF].astype(str)
    df.loc[df[COL_RUTA_PDF].isna(), "_RUTA_PDF"] = ""
    df["_RUTA_PDF"] = df["_RUTA_PDF"].str.strip()
    df["_RUTA_PDF_VALIDA"] = ~df["_RUTA_PDF"].str.upper().isin(["", "N/A", "NA", "NONE"])

    # Auxiliares de fecha
    df["_MES_NOMBRE"] = df["_FECHA_DT"].dt.month.map(MESES_ES)
    df["_DDMMYYYY"] = df["_FECHA_DT"].dt.strftime("%d-%m-%Y")
    df["_DDMMYY"]   = df["_FECHA_DT"].dt.strftime("%d%m%y")
    df["_MES_YY"]   = df["_FECHA_DT"].apply(month_folder_for_nomis)  # AGOSTO_25

    # Track de carpetas tocadas para dedup/limpieza
    graf_tocadas = set()
    fotos_tocadas = set()

    # 1) ESTRUCTURA + PDF (renombrado con SERIE)
    for i, row in df.iterrows():
        mes_nombre = row["_MES_NOMBRE"]
        carpeta_fecha = row["_DDMMYYYY"]
        zipper_char = row[COL_ZIPPER]  # 'M' o 'N'
        zipper_dir = f"ZIPPER {zipper_char}"

        # Solo meses existentes
        month_dir = BASE_DIR / zipper_dir / mes_nombre
        if not month_dir.is_dir():
            print(f"[OMITIDO] {zipper_dir}\\{mes_nombre} no existe. (Fecha {carpeta_fecha})")
            continue

        # Carpeta fecha
        fecha_dir = month_dir / carpeta_fecha
        if not fecha_dir.exists():
            fecha_dir.mkdir(parents=False, exist_ok=True)
            print(f"[CREADA] {fecha_dir}")
        else:
            print(f"[EXISTE] {fecha_dir}")

        # Subcarpetas
        for sub in SUBS:
            subdir = fecha_dir / sub
            if not subdir.exists():
                subdir.mkdir(parents=True, exist_ok=True)
                print(f"[CREADA] {subdir}")
            else:
                print(f"[EXISTE] {subdir}")

        # Copia/renombre de PDF a GRAFICAS
        if bool(row["_RUTA_PDF_VALIDA"]):
            src_pdf = Path(row["_RUTA_PDF"])
            dst_pdf_dir = fecha_dir / r"1.-DATOS DE CAMPO\GRAFICAS DE MONITOREO"
            graf_tocadas.add(dst_pdf_dir)
            if src_pdf.exists() and src_pdf.suffix.lower() == ".pdf":
                serie_val = re.sub(r"\D+", "", str(row.get(COL_SERIE, "")).strip())
                new_pdf_name = build_pdf_dst_name(src_pdf, serie_val)
                dst_pdf = dst_pdf_dir / new_pdf_name
                try:
                    if not dst_pdf.exists():
                        shutil.copy2(src_pdf, dst_pdf)
                        print(f"[COPIADO] {src_pdf.name} -> {dst_pdf}")
                    else:
                        # Si existe, no hacemos nada ahora: el dedup posterior por hash se encarga.
                        print(f"[EXISTE] Ya estaba copiado (renombrado): {dst_pdf}")
                except Exception as e:
                    print(f"[ERROR] Al copiar {src_pdf} -> {dst_pdf}: {e}")
            else:
                print(f"[OMITIDO] Ruta PDF inexistente o no .pdf: {src_pdf}")
        else:
            print(f"[OMITIDO] Sin ruta válida en {COL_RUTA_PDF} para FECHA {carpeta_fecha}.")

    # 2) NS8: copiar según eventos y LIMPIAR sobrantes
    grp = (
        df.assign(_EVT_INT=df[COL_EVT].map(to_int_safe))
          .dropna(subset=["_EVT_INT"])
          .groupby([COL_ZIPPER, "_FECHA_DT", COL_SERIE], dropna=False)["_EVT_INT"]
          .apply(lambda s: sorted(set(int(v) for v in s if v is not None)))
          .reset_index()
    )

    rx_range = re.compile(r"^Evts\s+(\d+)\s*-\s*(\d+)$", re.IGNORECASE)
    rx_evtfile = re.compile(r"^Evt0*([0-9]+)\.ns8$", re.IGNORECASE)

    for _, row in grp.iterrows():
        zipper_char = row[COL_ZIPPER]
        fecha_dt = row["_FECHA_DT"]
        serie = str(row[COL_SERIE]).strip()
        eventos_deseados = set(row["_EVT_INT"])
        if not eventos_deseados:
            continue

        mes_nombre = MESES_ES[fecha_dt.month]
        carpeta_fecha_entregable = dd_mm_yyyy(fecha_dt)
        zipper_dir = f"ZIPPER {zipper_char}"
        base_eventos_dst = (BASE_DIR / zipper_dir / mes_nombre / carpeta_fecha_entregable /
                            r"1.-DATOS DE CAMPO\EVENTOS")
        if not base_eventos_dst.exists():
            base_eventos_dst.mkdir(parents=True, exist_ok=True)

        mes_nomis = month_folder_for_nomis(fecha_dt)
        dia_nomis = ddmmyy(fecha_dt)
        serie_dir_name = f"NS8100-{serie}-Events"

        nomis_day_dir = NOMIS_BASE / mes_nomis / dia_nomis
        nomis_serie_dir = nomis_day_dir / serie_dir_name

        dst_serie_dir = base_eventos_dst / serie_dir_name

        if not nomis_serie_dir.exists():
            print(f"[OMITIDO] No existe fuente: {nomis_serie_dir} (SERIE {serie}, {carpeta_fecha_entregable})")
            # Limpieza si ya hubiera residuos
            if dst_serie_dir.exists():
                for p in dst_serie_dir.rglob("*.ns8"):
                    try:
                        p.unlink()
                        print(f"[ELIMINADO] {p} (sin fuente válida)")
                    except Exception as e:
                        print(f"[ERROR] Al eliminar {p}: {e}")
            continue

        range_dirs_src = [p for p in nomis_serie_dir.iterdir() if p.is_dir() and rx_range.match(p.name)]
        if not range_dirs_src:
            print(f"[OMITIDO] Sin subcarpetas 'Evts X-Y' en: {nomis_serie_dir}")
            if dst_serie_dir.exists():
                for p in dst_serie_dir.rglob("*.ns8"):
                    try:
                        p.unlink()
                        print(f"[ELIMINADO] {p} (sin rangos en fuente)")
                    except Exception as e:
                        print(f"[ERROR] Al eliminar {p}: {e}")
            continue

        dst_serie_dir.mkdir(parents=True, exist_ok=True)

        # COPIA deseados
        for evt in sorted(eventos_deseados):
            # elegir rango adecuado
            src_range_dir = None
            for rd in range_dirs_src:
                m = rx_range.match(rd.name)
                low, high = int(m.group(1)), int(m.group(2))
                if low <= evt <= high:
                    src_range_dir = rd
                    break
            if src_range_dir is None:
                print(f"[OMITIDO] No se encontró carpeta de rango para Evt{evt} en {nomis_serie_dir}")
                continue

            dst_range_dir = dst_serie_dir / src_range_dir.name
            if not dst_range_dir.exists():
                dst_range_dir.mkdir(parents=True, exist_ok=True)
                print(f"[CREADA] {dst_range_dir}")
            else:
                print(f"[EXISTE] {dst_range_dir}")

            copiado = False
            for cand in candidate_event_names(evt):
                src_file = src_range_dir / cand
                if src_file.exists():
                    dst_file = dst_range_dir / src_file.name
                    try:
                        if not dst_file.exists():
                            shutil.copy2(src_file, dst_file)
                            print(f"[COPIADO] {src_file} -> {dst_file}")
                        else:
                            print(f"[EXISTE] Ya estaba copiado: {dst_file}")
                        copiado = True
                        break
                    except Exception as e:
                        print(f"[ERROR] Al copiar {src_file} -> {dst_file}: {e}")
                        copiado = True
                        break
            if not copiado:
                print(f"[OMITIDO] No se encontró .ns8 para evento {evt} en {src_range_dir}")

        # LIMPIEZA sobrantes
        for dst_range_dir in [p for p in dst_serie_dir.iterdir() if p.is_dir() and rx_range.match(p.name)]:
            m = rx_range.match(dst_range_dir.name)
            low, high = int(m.group(1)), int(m.group(2))
            for f in list(dst_range_dir.iterdir()):
                if not f.is_file() or f.suffix.lower() != ".ns8":
                    continue
                mm = re.match(r"^Evt0*([0-9]+)\.ns8$", f.name, re.IGNORECASE)
                if not mm:
                    continue
                num_evt = int(mm.group(1))
                if num_evt not in eventos_deseados or not (low <= num_evt <= high):
                    try:
                        f.unlink()
                        print(f"[ELIMINADO] {f} (evento {num_evt} no está en la base)")
                    except Exception as e:
                        print(f"[ERROR] Al eliminar {f}: {e}")

    # 3) FASE FOTOS: copiar, renombrar ID->SERIE y limpiar vacíos
    if FOTOS_BASE.exists():
        for i, row in df.iterrows():
            if not bool(row["_RUTA_PDF_VALIDA"]):
                continue

            ddmmaa_pdf, id_pdf, ubic_pdf = parse_pdf_tokens_from_direccion(row["_RUTA_PDF"])
            if not (ddmmaa_pdf and id_pdf and ubic_pdf):
                print(f"[OMITIDO] No pude parsear DDMMAA/ID/UBICACION de: {row['_RUTA_PDF']}")
                continue

            fecha_dt = row["_FECHA_DT"]
            mes_nombre = MESES_ES[fecha_dt.month]
            carpeta_fecha_entregable = dd_mm_yyyy(fecha_dt)
            zipper_char = row[COL_ZIPPER]
            serie_val = re.sub(r"\D+", "", str(row[COL_SERIE]).strip())

            month_dir = BASE_DIR / f"ZIPPER {zipper_char}" / mes_nombre
            if not month_dir.is_dir():
                print(f"[OMITIDO] ZIPPER {zipper_char}\\{mes_nombre} no existe (FOTOS).")
                continue

            mes_yy = month_folder_for_nomis(fecha_dt)
            src_fotos_dir = FOTOS_BASE / mes_yy / ddmmaa_pdf / id_pdf / ubic_pdf
            if not src_fotos_dir.exists():
                print(f"[OMITIDO] No existe carpeta de fotos: {src_fotos_dir}")
                continue

            fecha_dir = month_dir / carpeta_fecha_entregable
            dst_root_fotos = fecha_dir / r"2.-FOTOS"
            dst_id_dir = dst_root_fotos / id_pdf / ubic_pdf
            dst_id_dir.mkdir(parents=True, exist_ok=True)

            # Copiar contenido
            for f in src_fotos_dir.iterdir():
                if f.is_file():
                    dst_f = dst_id_dir / f.name
                    try:
                        if not dst_f.exists():
                            shutil.copy2(f, dst_f)
                            print(f"[COPIADO] {f} -> {dst_f}")
                        else:
                            print(f"[EXISTE] Ya estaba copiado: {dst_f}")
                    except Exception as e:
                        print(f"[ERROR] Al copiar {f} -> {dst_f}: {e}")

            # Renombrar ID -> SERIE
            dst_serie_dir = dst_root_fotos / serie_val / ubic_pdf
            dst_serie_dir.parent.mkdir(parents=True, exist_ok=True)
            if dst_serie_dir.exists():
                # mover contenidos a carpeta de serie
                for f in list(dst_id_dir.iterdir()):
                    target = dst_serie_dir / f.name
                    if not target.exists():
                        shutil.move(str(f), str(target))
                        print(f"[MOVIDO] {f} -> {target}")
            else:
                shutil.move(str(dst_id_dir), str(dst_serie_dir))
                print(f"[RENOMBRADO] {dst_id_dir} -> {dst_serie_dir}")

            # limpiar posible padre <ID> vacío
            id_parent = dst_root_fotos / id_pdf
            try:
                if id_parent.exists() and not any(id_parent.iterdir()):
                    id_parent.rmdir()
            except Exception:
                pass

            # Renombrar PDFs dentro de 2.-FOTOS: DDMMAA_ID_IDX.pdf -> DDMMAA_SERIE_IDX.pdf
            for f in dst_serie_dir.iterdir():
                if f.is_file() and f.suffix.lower() == ".pdf":
                    parts = f.stem.split("_")
                    if len(parts) >= 3:
                        nuevo = f"{parts[0]}_{serie_val}_{parts[-1]}{f.suffix}"
                        new_path = f.with_name(nuevo)
                        if new_path != f and not new_path.exists():
                            try:
                                f.rename(new_path)
                                print(f"[RENOMBRADO] {f.name} -> {new_path.name}")
                            except Exception as e:
                                print(f"[ERROR] Al renombrar {f} -> {new_path}: {e}")

            fotos_tocadas.add(dst_root_fotos)

    # ====== DEDUPLICACIÓN FINAL Y LIMPIEZA ======
    # Dedup en todas las carpetas de GRAFICAS que tocamos
    total_borrados = 0
    for carpeta in sorted(graf_tocadas):
        res = dedup_pdfs_por_hash(carpeta)
        total_borrados += res.get("borrados", 0)

    # Dedup PDFs en fotos por serie/ubicación (por si quedaron duplicados por contenido)
    for root_fotos in sorted(fotos_tocadas):
        for serie_dir in root_fotos.iterdir() if root_fotos.exists() else []:
            if not serie_dir.is_dir():
                continue
            for ubic_dir in serie_dir.iterdir():
                if not ubic_dir.is_dir():
                    continue
                dedup_pdfs_por_hash(ubic_dir)

    # Borrar carpetas vacías en todo el día tocado
    # (subimos a las fechas detectadas desde las rutas tocadas)
    fechas_set = set()
    for p in list(graf_tocadas) + list(fotos_tocadas):
        # ...\ZIPPER X\MES\DD-MM-YYYY\...
        try:
            fecha_dir = p.parents[0].parents[0]  # subir dos: GRAFICAS->1.-DATOS->DD-MM-YYYY
            if fecha_dir.exists():
                fechas_set.add(fecha_dir)
        except Exception:
            pass
    total_vacias = 0
    for fecha_dir in sorted(fechas_set):
        total_vacias += borrar_carpetas_vacias(fecha_dir)

    # NUEVO: eliminar carpetas de 1-2 dígitos dentro de 2.-FOTOS
    eliminadas_cortas = eliminar_carpetas_fotos_ids_cortos(fotos_tocadas)

    print("\n[LISTO] Proceso terminado.")
    print(f"[RESUMEN] PDFs duplicados eliminados por hash: {total_borrados}")
    print(f"[RESUMEN] Carpetas vacías removidas: {total_vacias}")
    print(f"[RESUMEN] Carpetas 'ID cortas' eliminadas en 2.-FOTOS: {eliminadas_cortas}")

if __name__ == "__main__":
    main()
