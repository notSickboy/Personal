import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading
import requests
import io
import contextlib
import importlib
import sys

ARCHIVO_GITHUB = 'https://raw.githubusercontent.com/notSickboy/Personal/main/SERIAL_DB'

# Asociamos los botones con nombres de módulo
scripts = {
    "Paso 1: Cambiar horas en SPG": "lib_1",
    "Paso 2: Consolida reportes digitales": "lib_2",
    "Paso 3: Comparar horas NOMI-PFS": "lib_3",
    "Paso 4: Exportar archivo DB": "lib_4"
}

def verificar_archivo_github():
    try:
        respuesta = requests.head(ARCHIVO_GITHUB, timeout=5)
        return respuesta.status_code == 200
    except:
        return False

def ejecutar_script(nombre_logico):
    consola.config(state='normal')
    consola.delete(1.0, tk.END)
    consola.insert(tk.END, f"▶️ Ejecutando: {nombre_logico}\n")

    nombre_modulo = scripts[nombre_logico]

    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        try:
            modulo = importlib.import_module(nombre_modulo)
            modulo.main()
        except Exception as e:
            print(f"❌ Error: {str(e)}")

    salida = f.getvalue()
    consola.insert(tk.END, salida)
    consola.insert(tk.END, "\n✅ Finalizado.\n")
    consola.config(state='disabled')

def hilo_ejecucion(nombre_logico):
    threading.Thread(target=ejecutar_script, args=(nombre_logico,), daemon=True).start()

# Verificar archivo antes de mostrar GUI
if not verificar_archivo_github():
    root = tk.Tk()
    root.withdraw()  # Ocultar la ventana principal
    messagebox.showerror("Error", "No se verificó una librería.\nConéctate a internet.")
    sys.exit(1)

# GUI (solo se ejecuta si el archivo fue encontrado)
ventana = tk.Tk()
ventana.title("Herramienta de DB Monitoreo")
ventana.geometry("480x350")

frame_botones = tk.Frame(ventana)
frame_botones.pack(pady=10)

for nombre_logico in scripts.keys():
    b = tk.Button(frame_botones, text=nombre_logico, width=50,
                  command=lambda n=nombre_logico: hilo_ejecucion(n))
    b.pack(pady=4)

consola = scrolledtext.ScrolledText(ventana, height=10, font=("Courier New", 10))
consola.pack(fill="x", padx=10, pady=10)
consola.config(state='disabled')

ventana.mainloop()
